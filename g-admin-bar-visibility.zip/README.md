wp-g-admin-bar-visibility
=========================

WP Plugin that allow user to hide admin bar for all user except admin user on the back-end
